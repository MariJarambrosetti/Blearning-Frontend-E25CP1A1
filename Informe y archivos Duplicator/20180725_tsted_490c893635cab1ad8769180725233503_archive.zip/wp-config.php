<?php
/** 
 * Configuración básica de WordPress.
 *
 * Este archivo contiene las siguientes configuraciones: ajustes de MySQL, prefijo de tablas,
 * claves secretas, idioma de WordPress y ABSPATH. Para obtener más información,
 * visita la página del Codex{@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} . Los ajustes de MySQL te los proporcionará tu proveedor de alojamiento web.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** Ajustes de MySQL. Solicita estos datos a tu proveedor de alojamiento web. ** //
/** El nombre de tu base de datos de WordPress */
define('DB_NAME', 'feg7mari_tarea_final');

/** Tu nombre de usuario de MySQL */
define('DB_USER', 'feg7mari_usr');

/** Tu contraseña de MySQL */
define('DB_PASSWORD', 'S1ae4DqN4w20');

/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define('DB_HOST', 'localhost');

/** Codificación de caracteres para la base de datos. */
define('DB_CHARSET', 'utf8');

/** Cotejamiento de la base de datos. No lo modifiques si tienes dudas. */
define('DB_COLLATE', '');

/**#@+
 * Claves únicas de autentificación.
 *
 * Define cada clave secreta con una frase aleatoria distinta.
 * Puedes generarlas usando el {@link https://api.wordpress.org/secret-key/1.1/salt/ servicio de claves secretas de WordPress}
 * Puedes cambiar las claves en cualquier momento para invalidar todas las cookies existentes. Esto forzará a todos los usuarios a volver a hacer login.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '-J+N->7N-RUw=#IQG;X-hMW leE+*-:mNd+S_T>8lxQ <w;Ayg0y*KH~z2?7/nv)'); // Cambia esto por tu frase aleatoria.
define('SECURE_AUTH_KEY', 'Eog|}l^i.| >`u:E+9Z4Jkr3^w`U)5`En[V},[Z90_eEsQmo0CZLDF.|yKj$Fqm+'); // Cambia esto por tu frase aleatoria.
define('LOGGED_IN_KEY', ':_H5f/ q+H>Tx`D6)*i0-T(6j5~|O0@;y9|W$q.,+#]aXJ&1MX_#|<{||) y@Yoi'); // Cambia esto por tu frase aleatoria.
define('NONCE_KEY', 'l*7#`c%_yg^AyM_n]G|zd~l9Z$OYuB1mqd[|5i1iIXI=13d9@*KZ+[kM&]m=UlN#'); // Cambia esto por tu frase aleatoria.
define('AUTH_SALT', 'h79GiL`<:MiFY(~yu|/c8N0Lb5#FzBRa~$2H9~bW/CsZoDHLBi~$GIF1^20&;d>.'); // Cambia esto por tu frase aleatoria.
define('SECURE_AUTH_SALT', 'G#PK0-]XLWth0He (o+wR80KQ;>xqId01S-eK)oHO~_ S9a<bfnM&v$Wl6uk1>[N'); // Cambia esto por tu frase aleatoria.
define('LOGGED_IN_SALT', '+eV$SvWfKe=|V&((,bGN%{;w?i[Q3 6#QriyJ5F+pRsM+[*R0)m!/z|-rRb4C#E='); // Cambia esto por tu frase aleatoria.
define('NONCE_SALT', ';L*T-r&Ze>q!$xe&sL$|<Yq=DDDlvfct.kxGFen*ofrOd./cKhGWAN1}>tKrmeDu'); // Cambia esto por tu frase aleatoria.

/**#@-*/

/**
 * Prefijo de la base de datos de WordPress.
 *
 * Cambia el prefijo si deseas instalar multiples blogs en una sola base de datos.
 * Emplea solo números, letras y guión bajo.
 */
$table_prefix  = 'wp_';

/**
 * Idioma de WordPress.
 *
 * Cambia lo siguiente para tener WordPress en tu idioma. El correspondiente archivo MO
 * del lenguaje elegido debe encontrarse en wp-content/languages.
 * Por ejemplo, instala ca_ES.mo copiándolo a wp-content/languages y define WPLANG como 'ca_ES'
 * para traducir WordPress al catalán.
 */
define('WPLANG', 'es_ES');

/**
 * Para desarrolladores: modo debug de WordPress.
 *
 * Cambia esto a true para activar la muestra de avisos durante el desarrollo.
 * Se recomienda encarecidamente a los desarrolladores de temas y plugins que usen WP_DEBUG
 * en sus entornos de desarrollo.
 */
define('WP_DEBUG', false);

/* ¡Eso es todo, deja de editar! Feliz blogging */

/** WordPress absolute path to the Wordpress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

