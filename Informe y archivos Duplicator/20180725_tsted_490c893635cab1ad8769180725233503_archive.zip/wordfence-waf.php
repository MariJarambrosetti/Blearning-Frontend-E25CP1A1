<?php
// Before removing this file, please verify the PHP ini setting `auto_prepend_file` does not point to this.

// This file was the current value of auto_prepend_file during the Wordfence WAF installation (Wed, 25 Jul 2018 02:43:10 +0000)
if (file_exists('/usr/local/bin/env.php')) {
	include_once '/usr/local/bin/env.php';
}
if (file_exists('/home/feg7mariana/public_html/wp-content/plugins/wordfence/waf/bootstrap.php')) {
	define("WFWAF_LOG_PATH", '/home/feg7mariana/public_html/wp-content/wflogs/');
	include_once '/home/feg7mariana/public_html/wp-content/plugins/wordfence/waf/bootstrap.php';
}
?>